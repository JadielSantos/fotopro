<?php $__env->startSection('tool'); ?>
  <form action="<?php echo e(route('galleries.store')); ?>" class="form" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="form__group">
      <input id="title" type="text" class="form__input" name="title" placeholder="Título" value="<?php echo e(old('name')); ?>" required autocomplete="title" autofocus>
      <label for="title" class="form__label"><?php echo e(__('Título')); ?></label>
    </div>

    <div class="form__group">
      <input id="images" class="form__input" placeholder="Imagens" value="<?php echo e(old('title')); ?>" type="file" name="images[]" multiple>
    </div>

    <div class="form__group">
      <button class="btn btn--green" type="submit">Enviar Imagens</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('logged-in.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/fotopro/resources/views/logged-in/tools/gallery/create.blade.php ENDPATH**/ ?>