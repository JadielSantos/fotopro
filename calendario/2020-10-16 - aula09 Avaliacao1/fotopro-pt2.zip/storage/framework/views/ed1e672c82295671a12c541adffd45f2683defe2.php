<?php $__env->startSection('tool'); ?>
  <section class="section-gallery">
    <a href="<?php echo e(route('galleries.create')); ?>" class="btn btn--green"><?php echo e(__('Criar Galeria')); ?></a>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('logged-in.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/fotopro/resources/views/logged-in/tools/gallery/index.blade.php ENDPATH**/ ?>