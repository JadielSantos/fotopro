<script src="<?php echo e(asset('vendor/landing-page/js/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/landing-page/js/bootstrap.bundle.min.js')); ?>"></script>
<?php /**PATH /var/www/projects/fotopro/resources/views/partials/scripts.blade.php ENDPATH**/ ?>