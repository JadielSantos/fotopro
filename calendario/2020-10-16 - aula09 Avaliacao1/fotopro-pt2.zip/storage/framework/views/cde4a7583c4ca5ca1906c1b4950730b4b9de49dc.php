<header class="header">




  <div class="header__text-box">
    <h1 class="heading-primary">
      <span class="heading-primary--main">Fotopro</span>
      <span class="heading-primary--sub">Fazemos acontecer</span>
    </h1>

    <a href="<?php echo e(route('register')); ?>" class="btn btn--white btn--animated">Comece a usar</a>
  </div>
</header>
<?php /**PATH /var/www/projects/fotopro/resources/views/partials/header.blade.php ENDPATH**/ ?>