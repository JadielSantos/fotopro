<section class="section-features">

  <div class="row">
    <div class="col-1-of-4">
      <div class="feature-box">
        <i class="feature-box__icon icon-basic-world"></i>
        <h3 class="heading-tertiary u-margin-bottom-small">Multiplataforma</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore necessitatibus deleniti dolorum!</p>
      </div>
    </div>

    <div class="col-1-of-4">
      <div class="feature-box">
        <i class="feature-box__icon icon-basic-compass"></i>
        <h3 class="heading-tertiary u-margin-bottom-small">Organize seu trabalho</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore necessitatibus deleniti dolorum!</p>
      </div>
    </div>

    <div class="col-1-of-4">
      <div class="feature-box">
        <i class="feature-box__icon icon-basic-map"></i>
        <h3 class="heading-tertiary u-margin-bottom-small">ácil de usar</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore necessitatibus deleniti dolorum!</p>
      </div>
    </div>

    <div class="col-1-of-4">
      <div class="feature-box">
        <i class="feature-box__icon icon-basic-heart"></i>
        <h3 class="heading-tertiary u-margin-bottom-small">Compartilhe</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore necessitatibus deleniti dolorum!</p>
      </div>
    </div>
  </div>
</section>
<?php /**PATH /var/www/projects/fotopro/resources/views/partials/feature.blade.php ENDPATH**/ ?>
