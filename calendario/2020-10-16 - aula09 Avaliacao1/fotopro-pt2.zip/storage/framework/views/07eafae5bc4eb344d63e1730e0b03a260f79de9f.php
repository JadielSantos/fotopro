<?php $__env->startSection('tool'); ?>
<h1 class="heading-secondary">LISTA GALERIAS DO USUARIO</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('logged-in.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/fotopro/resources/views/logged-in/tools/index.blade.php ENDPATH**/ ?>
