<form action="<?php echo e(route('galerias.create')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input class="custom-file-input" type="text" name="title">
  <input class="custom-file-input" type="file" name="file">
  <button class="btn btn-primary" type="submit">Enviar Imagens</button>
</form>
<?php /**PATH /var/www/projects/fotopro/resources/views/gallery/create.blade.php ENDPATH**/ ?>