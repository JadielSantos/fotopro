<section class="section-book">
  <div class="row">
    <div class="book">
      <div class="book__form">
        <form action="<?php echo e(route('register')); ?>" class="form">
          <div class="u-margin-bottom-medium">
            <h2 class="heading-secondary">
              Comece agora!
            </h2>
          </div>
          <div class="form__group">
            <input type="text" class="form__input" placeholder="Nome Completo" id="name" required>
            <label for="name" class="form__label">Nome Completo</label>
          </div>
          <div class="form__group">
            <input type="email" class="form__input" placeholder="E-mail" id="email" required>
            <label for="email" class="form__label">E-mail</label>
          </div>



















          <div class="form__group">
            <button class="btn btn--green">Próximo passo &rarr;</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<?php /**PATH /var/www/projects/fotopro/resources/views/partials/cta-register.blade.php ENDPATH**/ ?>