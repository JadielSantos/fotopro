<?php $__env->startSection('content'); ?>
  <section class="section-home">
    <div class="flex">
      <div class="flex__row flex__row-up">

        <div class="flex__row--item-left user-info u-text-center">
          <img src="<?php echo e(asset('/img/profile.png')); ?>" alt="User photo" style="height: 50px; margin-right: 1rem">
          <div>
            <h3 class="heading-tertiary"><?php echo e(Auth::user()->name); ?></h3>
            <div>
              <i class="icon-basic-star" style="font-size: 1.5rem"></i>
              <i class="icon-basic-star" style="font-size: 1.5rem"></i>
              <i class="icon-basic-star" style="font-size: 1.5rem"></i>
              <i class="icon-basic-star" style="font-size: 1.5rem"></i>
              <i class="icon-basic-star" style="font-size: 1.5rem"></i>
            </div>
          </div>
        </div>

        <div class="flex__row--item-right section-title">
          <i class="icon-basic-picture feature-box__icon" style="font-size: 5rem;"></i>
        </div>

      </div>

      <div class="flex__row">

        <div class="flex__row--item-left side-menu-container">
          <ul class="side-menu">
            <li class="heading-tertiary u-margin-bottom-small"><a href="<?php echo e(route('galleries.index')); ?>"><?php echo e(__("Seleção de Fotos")); ?></a></li>
            <li class="heading-tertiary u-margin-bottom-small"><a href="<?php echo e(route('home')); ?>"><?php echo e(__("Clientes")); ?></a></li>
            <li class="heading-tertiary u-margin-bottom-small"><a href="<?php echo e(route('home')); ?>"><?php echo e(__("Pagamentos")); ?></a></li>
            <li class="heading-tertiary u-margin-bottom-small"><a href="<?php echo e(route('home')); ?>"><?php echo e(__("Suporte")); ?></a></li>
          </ul>
        </div>

        <div class="flex__row--item-right">
          <?php echo $__env->yieldContent('tool'); ?>
        </div>

      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/fotopro/resources/views/logged-in/home.blade.php ENDPATH**/ ?>