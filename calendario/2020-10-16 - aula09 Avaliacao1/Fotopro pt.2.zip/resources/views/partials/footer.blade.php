<footer class="footer">
  {{--  <div class="footer__logo-box">--}}
  {{--    <img src="{{ asset('img/icon.png') }}" alt="Fotopro logo" class="footer__logo">--}}
  {{--  </div>--}}
  <div class="row">
    <div class="col-1-of-2">
      <div class="footer__navigation">
        <ul class="footer__list">
          <li class="footer__item"><a href="#" class="footer__link">Empresa</a></li>
          <li class="footer__item"><a href="#" class="footer__link">Fale conosco</a></li>
          <li class="footer__item"><a href="#" class="footer__link">Política de privacidade</a></li>
          <li class="footer__item"><a href="#" class="footer__link">Termos de uso</a></li>
        </ul>
      </div>
    </div>
    <div class="col-1-of-2">
      <p class="footer__copyright">
        Design feito por <a href="" class="footer__link">Jadiel dos Santos</a>. Copyright &copy; by Jonas Schmedtmann.
      </p>
    </div>
  </div>
</footer>
