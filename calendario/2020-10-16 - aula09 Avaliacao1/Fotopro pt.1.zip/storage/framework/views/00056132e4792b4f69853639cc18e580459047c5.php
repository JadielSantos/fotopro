<?php $__env->startSection('tool'); ?>
  <section class="section-gallery-item">
    <h2 class="heading-tertiary"><?php echo e($gallery->title); ?></h2>

    <?php $__currentLoopData = $gallery->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($image->path); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('logged-in.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/fotopro/resources/views/logged-in/tools/gallery/show.blade.php ENDPATH**/ ?>
