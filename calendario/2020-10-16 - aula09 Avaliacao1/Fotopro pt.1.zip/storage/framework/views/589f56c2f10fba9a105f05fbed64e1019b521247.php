<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laravel + Bootstrap</title>

  <link rel="stylesheet" href="<?php echo e(asset('site/app.css')); ?>">
</head>
<body>
  <script src="<?php echo e(asset('site/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('site/bootstrap.js')); ?>"></script>

  <h1>Testando Bootstrap</h1>

  <button class="btn btn-lg btn-orange">Bootstrap OK!</button>

</body>
</html>
<?php /**PATH /var/www/projects/fotopro/resources/views/test.blade.php ENDPATH**/ ?>