<section class="call-to-action text-white text-center">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-xl-9 mx-auto">
                <h2 class="mb-4">Pronto para começar? Registre-se agora!</h2>
            </div>
            <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                <form>
                    <div class="form-row">
                        <div class="col-12 col-md-9 mb-2 mb-md-0">
                            <input type="email" class="form-control form-control-lg" placeholder="Insira seu e-mail...">
                        </div>
                        <div class="col-12 col-md-3">
                            <button type="submit" class="btn btn-block btn-lg btn-primary">Registre-se!</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/projects/fotopro/resources/views/landing-page/partials/plans.blade.php ENDPATH**/ ?>
