<nav class="navbar navbar-light bg-light static-top">
    <div class="container">
      <a class="navbar-brand" href="#">FotoPro</a>
      <div class="">
        <a class="btn btn-primary" href="#">Entrar</a>
        <a class="btn btn-secondary" href="#">Registrar-se</a>
      </div>
    </div>
</nav>
<?php /**PATH /var/www/projects/fotopro/resources/views/landing-page/partials/navigation.blade.php ENDPATH**/ ?>