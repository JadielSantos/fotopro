<section class="features-icons bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
                    <div class="features-icons-icon d-flex">
                        <i class="icon-screen-desktop m-auto text-primary"></i>
                    </div>
                    <h3>Multiplataforma</h3>
                    <p class="lead mb-0">Duis nec convallis mauris, et sagittis mauris.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
                    <div class="features-icons-icon d-flex">
                        <i class="icon-layers m-auto text-primary"></i>
                    </div>
                    <h3>Organize seu trabalho</h3>
                    <p class="lead mb-0">Vivamus gravida neque ac posuere tristique.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="features-icons-item mx-auto mb-0 mb-lg-3">
                    <div class="features-icons-icon d-flex">
                        <i class="icon-check m-auto text-primary"></i>
                    </div>
                    <h3>Fácil de usar</h3>
                    <p class="lead mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce cursus mattis mauris.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/projects/fotopro/resources/views/landing-page/partials/feature.blade.php ENDPATH**/ ?>
