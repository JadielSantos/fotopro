<h1>Página de Contato</h1>
<?php /**PATH /var/www/projects/fotopro/resources/views/contact.blade.php ENDPATH**/ ?>