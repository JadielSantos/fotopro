<a href="<?php echo e(route('landing-page')); ?>">< Voltar</a>

<h1>Página de fotos</h1>

<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/projects/fotopro/resources/views/user/photos.blade.php ENDPATH**/ ?>