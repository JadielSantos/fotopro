<h1>Página de Contato</h1>

<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/projects/fotopro/resources/views/user/contacts.blade.php ENDPATH**/ ?>