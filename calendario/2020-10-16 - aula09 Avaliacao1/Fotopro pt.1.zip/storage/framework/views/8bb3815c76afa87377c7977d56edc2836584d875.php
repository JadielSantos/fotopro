<a href="<?php echo e(route('landing-page')); ?>">< Voltar</a>

<h1>Página Principal Logado</h1>

<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/projects/fotopro/resources/views/user/home.blade.php ENDPATH**/ ?>