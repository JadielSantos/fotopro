<nav class="nav-menu">
  <ul class="menu">
    <li><a href="<?php echo e(route('home')); ?>">Início</a></li>
    <li><a href="#!">Sobre</a></li>
    <li><a href="#!">Fale Conosco</a></li>
    <li><a href="#!">FAQ</a></li>

    <div class="menu--right">
      <?php if(auth()->guard()->guest()): ?>
        <li>
          <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Entrar')); ?></a>
        </li>
        <?php if(Route::has('register')): ?>
          <li>
            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrar')); ?></a>
          </li>
        <?php endif; ?>
      <?php else: ?>
        <li>
          <a id="navbarDropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?>

          </a>
        </li>

        <li>
          <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <?php echo e(__('Sair')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </li>
      <?php endif; ?>
    </div>
  </ul>
</nav>
<?php /**PATH /var/www/projects/fotopro/resources/views/partials/navigation.blade.php ENDPATH**/ ?>